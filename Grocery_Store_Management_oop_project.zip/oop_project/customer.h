#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>



using namespace std;

int main();

class User
{
protected:
    char name[20];
    char password[20];
    char CNIC[20];
    char phone[20];
    char adress[20];
public:
    User() {
        //inizalizing each attributes 
        for (int i = 0; i < 20; i++)
        {
            password[i] = '\0';
            adress[i] = '\0';
            name[i] = '\0';
            CNIC[i] = '\0';
            phone[i] = '\0';

        }
    }
    User(string name, string pass, string cnic, string ph, string adress)
    {
        //copying data from parameters to variables
        strcpy_s(this->name, name.c_str());
        strcpy_s(this->password, pass.c_str());
        strcpy_s(this->CNIC, cnic.c_str());
        strcpy_s(this->phone, ph.c_str());
        strcpy_s(this->adress, adress.c_str());
    }

    // Setters/Getters

    void setName(string n1) {
        strcpy_s(this->name, n1.c_str());
    }
    string getName() {
        return name;
    }
    void setpass(string p1) {
        strcpy_s(this->password, p1.c_str());
    }
    string getpass() {
        return password;
    }
    void setCNIC(string cnic1) {
        strcpy_s(this->CNIC, cnic1.c_str());
    }
    string getCNIC() {
        return CNIC;
    }
    void setPhone(string p1) {
        strcpy_s(this->phone, p1.c_str());
    }
    string getPhone() {
        return phone;
    }
    void setAddress(string A1) {
        strcpy_s(this->adress, A1.c_str());
    }
    string getAddress() {
        return adress;
    }
};

const string file_name = "product.bin";
const string filename = "inventory.bin";
//********************************************************************

// Catalog Class

//*******************************************************************


class product_catalog
{
public:
    char catagory[25];
    
    char prod_name[25];
    char prod_unit[25];
    float prod_price;

    product_catalog() {
        for (int i = 0; i < 25; i++)
        {
            catagory[i] = '\0';
            prod_name[i] = '\0';
            prod_unit[i] = '\0';
        }
        prod_price = 0;
    }
    //copying data from parameters to variables
    product_catalog(string cata, string p_name, string unit, float p_price) {
        //copying data from parameters to variables
        strcpy_s(this->catagory, cata.c_str());
        strcpy_s(this->prod_name, p_name.c_str());
        strcpy_s(this->prod_unit, unit.c_str());
        prod_price = p_price;
        

    }
    bool check;
    //function for searching in binary file
    void search(const string file_name, string product)
    {
        product_catalog pc;
        fstream file(file_name.c_str(), ios::in | ios::out | ios::binary);
        while (file.read((char*)&pc, sizeof(pc)))    // reading the file                                                             
        {
            if (product == pc.prod_name)
            {
                check = true;
                //cout << "Yes\n";
                //price = pc.prod_price;
                // cout << price;
                file.close();


            }
            else
            {
                check = false;
            }
        }


    }
    
    
    //Displaying Catalog
    void catalog_display();


    //function to add products
    void add_product();
    //function to delete products
    void remove_product();
    //function to edit products
    void edit_product();
};

void product_catalog::add_product() {
    product_catalog p1;
    //admin a1;
    char input;
    int choice1,choice2;
    cout << "\n _________________________\n";
    cout << "|Select the catagory        |\n";
    cout << "|1.Food                     |\n";
    cout << "|2.Personal Hygiene         |\n";
    cout << "|3.Household Cleaning       |\n";
    cout << "|4.Main Menu                |\n";
    cout << "|___________________________|\n";
    do
    {
        cout << "Press: ";
        cin >> choice1;
    } while (choice1 != 1 && choice1 != 2 && choice1 != 3 && choice1 != 4);

    if (choice1 == 1) {
        do
        {
            cout << "-------------------------";
            cout << "\nFood\n";
            cout << "\nProduct Name: ";
            cin >> p1.prod_name;
            cout << "Product Price :";
            cin >> p1.prod_price;
            cout << "Product Unit :";
            cin >> p1.prod_unit;

            ofstream file("product.bin", ios::binary | ios::app);
            //writng in binary file
            if (file.write((char*)&p1, sizeof(p1))) 
            {
                cout << "Successfully Inserted\n" << endl;
            }
            else
            {
                cout << "Failed" << endl;
            }
            file.close();
            do
            {
                cout << "Press y to continue Or n to exit: ";
                cin >> input;
            } while (input != 'y' && input != 'n');

        } while (input == 'y');
        if (input != 'y')
        {
            add_product();
        }
    }
    else if (choice1 == 2) {
        do
        {
            cout << "-------------------------";
            cout << "\nPersonal Hygiene\n";
            cout << "\nProduct Name: ";
            cin >> p1.prod_name;
            cout << "Product Price :";
            cin >> p1.prod_price;
            cout << "Product Unit :";
            cin >> p1.prod_unit;

            ofstream file("product.bin", ios::binary | ios::app);

            if (file.write((char*)&p1, sizeof(p1)))
            {
                cout << "Successfully Inserted\n" << endl;
            }
            else
            {
                cout << "Failed" << endl;
            }
            file.close();
            do
            {
                cout << "Press y to continue Or n to exit: ";
                cin >> input;
            } while (input!='y' && input != 'n');
            
        } while (input =='y');
        if (input!='y')
        {
            add_product();
        }
   
    }
    else if (choice1 == 3)
    {

        do
        {
            cout << "-------------------------";
            cout << "\nHousehold Cleaning\n";
            cout << "\nProduct Name: ";
            cin >> p1.prod_name;
            cout << "Product Price :";
            cin >> p1.prod_price;
            cout << "Product Unit :";
            cin >> p1.prod_unit;

            ofstream file("product.bin", ios::binary | ios::app);

            if (file.write((char*)&p1, sizeof(p1)))
            {
                cout << "Successfully Inserted\n" << endl;
            }
            else
            {
                cout << "Failed" << endl;
            }
            file.close();
            do
            {
                cout << "Press y to continue / n to exit: ";
                cin >> input;
            } while (input != 'y' && input != 'n');

        } while (input == 'y');
        if (input != 'y')
        {
            add_product();
        }
    }
    else 
    {
       // a1.display_admin();
       system("CLS");
       main();
    }

}

//function to dispaly catalog
void product_catalog::catalog_display() {
    product_catalog p2;


    ifstream file("product.bin", ios::binary | ios::app);

    while (file.read((char*)&p2, sizeof(p2)))
    {
        cout << "\n-------------------------\n";
        cout << "Product Name  : " << p2.prod_name << endl;
        cout << "Product Price :" << p2.prod_price << endl;
        cout << "Product Unit  :" << p2.prod_unit << endl;
        
    }
   
    file.close();
    add_product();

}

//function to edit catalog
void product_catalog::edit_product() {
    string name;
    int new_price;
    product_catalog p3;
    cout << "Product Name (Update): ";
    cin >> name;
    cout << "Updated Price: ";
    cin >> new_price;


    //search("product.bin",name );
    fstream file(file_name.c_str(), ios::in | ios::out | ios::binary);
    while (file.read((char*)&p3, sizeof(p3)))
    {
        if (p3.prod_name == name);
        {
            p3.prod_price = new_price;
            int first_ptr = file.tellg();
            int size = sizeof(p3);
            file.seekp(first_ptr - size, ios::beg);
            file.write((char*)&p3, sizeof(p3));
            break;
        }
        
    }
    file.close();
   
    system("CLS");
    main();
}

//function to remove products
void product_catalog::remove_product() {
    char input;
    string product;
    product_catalog p;
    cout << "Eneter the product you want to delete: ";
    cin >> product;

    search("product.bin", product);
    do
    {
        if (check==true)
        {
            fstream myFile(file_name.c_str(), ios::in | ios::out | ios::binary);
            ofstream myFileTemp("product.bin", ios::app | ios::binary);
            while (myFile.read((char*)&p, sizeof(p))) {
                if (p.prod_name != product) {
                    myFileTemp.write((char*)&p, sizeof(p));
                }
            }


            myFile.close();
            myFileTemp.close();
            remove(file_name.c_str());
            rename("product.bin", file_name.c_str());
        }
        do
        {
            cout << "Press y to continue / n to exit: ";
            cin >> input;
        } while (input != 'y' && input != 'n');

    } while (input == 'y');
    
    main();
}


//********************************************************************

// Inventory Class

//*******************************************************************

class Inventory
{
public:
    int price;
    char item[25];
    bool check;

   
    //function for store inventory
    void multan_store() {
        int choice;
        cout << "\n _______________________________\n";
        cout << " Welcom To Multan Store \n";
        cout << "\n _______________________________\n";
        cout << "|1. Add Products in Inventory     |\n";
        cout << "|2. View Products in Inventory    |\n";
        cout << "|3. Edit/Update Products          |\n";
        cout << "|4. Delete Products               |\n";
        cout << "|5. Main Menu                     |\n";
        cout << "|_________________________________|\n";
        do
        {
            cout << "Press: ";
            cin >> choice;
        } while (choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5);
        if (choice==1)
        {
            M_add_item();
            multan_store();
        }
        if (choice == 2)
        {
            M_view_data();
            multan_store();
        }
        if (choice == 3)
        {
            M_edit_item();
            multan_store();
        }
        if (choice == 4)
        {
            M_delete_item();
            multan_store();
        }
        if (choice == 5)
        {
            system("CLS");
            main();
        }
    }
    //function for store inventory
    void isb_store() {
        int choice;
        cout << "\n -------------------------------\n";
        cout << " Welcom To Islamabad Store \n";
        cout << "\n -------------------------------\n";
        cout << "|1. Add Products in Inventory     |\n";
        cout << "|2. View Products in Inventory    |\n";
        cout << "|3. Edit/Update Products          |\n";
        cout << "|4. Delete Products               |\n";
        cout << "|5. Main Menu                     |\n";
        cout << "|_________________________________|\n";
        do
        {
            cout << "Press: ";
            cin >> choice;
        } while (choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5);

        if (choice == 1)
        {

            Isb_add_item();
            isb_store();
        }
        if (choice == 2)
        {
            Isb_view_data();
            isb_store();
        }
        if (choice == 3)
        {
            Isb_edit_item();
            isb_store();
        }
        if (choice == 4)
        {
            Isb_delete_item();
            isb_store();
        }
        if (choice == 5)
        {
            system("CLS");
            main();
        }
    }


    //=====================
    //Function for Multan Store
    //=====================

    void M_add_item() {
        
        Inventory i1;
        product_catalog pc;
        char input;
        do
        {
            cout << "\n -------------------------------\n";
            cout << "Enter the product you want to add: ";
            cin >> i1.item;
            // M_search("product.bin", i1.item);
            //if (check == true)
            //{
                //cout << "Product found" << endl;
                cout << "Enter the Price of product: ";
                cin >> i1.price;

                ofstream file;
                
                file.open("M_inventory.bin", ios::binary | ios::app);
                if (file.write((char*)&i1, sizeof(i1)))
                {
                    cout << "Successfully Inserted\n" << endl;
                }
                else
                {
                    cout << "Failed" << endl;
                }
                file.close();
            //}
            //else
           // {
              //  cout << "\n* Product not found\n";
            //}
            do
            {
                cout << "Press y to continue / n to exit: ";
                cin >> input;
            } while (input != 'y' && input != 'n');

        } while (input=='y');
        

    }
    void M_edit_item() {

        char name[25];
        int new_price;
        cout << "Product Name (Update): ";
        cin >> name;
        cout << "Updated Price: ";
        cin >> new_price;
        M_update("M_inventory.bin", name, new_price);


    }
    void M_view_data() {
        

        ifstream file;
        Inventory i1;
        file.open("M_inventory.bin", ios::binary | ios::app);

        while (file.read((char*)&i1, sizeof(i1)))
        {
            cout << "\n-------------------------\n";
            cout << "Product Name  : " << i1.item << endl;
            cout << "Product Price :" << i1.price << endl;
            

        }

        file.close();
        //add_product();

    }

    void M_update(const string filename,string item, int quantity)
    {
        Inventory i3;
        fstream file(file_name.c_str(), ios::in | ios::out | ios::binary);
        while (file.read((char*)&i3, sizeof(i3)))
        {
           if(item == i3.item)
            {
                i3.price = quantity;
                int first_ptr = file.tellg();
                int size = sizeof(i3);
                file.seekp(first_ptr - size, ios::beg);
                file.write((char*)&i3, sizeof(i3));
                file.close();
            }
        }
        
    }

    void M_search(const string filename, string product)
    {
        product_catalog pc;
        fstream file(file_name.c_str(), ios::in | ios::out | ios::binary);
        while (file.read((char*)&pc, sizeof(pc)))
        {
            if (product == pc.prod_name)
            {
                check = true;
                cout << "Yes\n";
                file.close();

            }
            else
            {
                check = false;
            }
        }
        
    }

    void M_delete_item() {
        string product;
        Inventory p;
        cout << "Enter the product you want to delete: ";
        cin >> product;
        fstream myFile(filename.c_str(), ios::in | ios::out | ios::binary);
        ofstream myFileTemp("M_inventory.bin", ios::app | ios::binary);
        while (myFile.read((char*)&p, sizeof(p))) {
            if (p.item != product) {
                myFileTemp.write((char*)&p, sizeof(p));
            }
        }


        myFile.close();
        myFileTemp.close();
        remove(filename.c_str());
        rename("M_inventory.bin", filename.c_str());
    }


    //=====================
    //Function for Islamabad Store
    //=====================

    void Isb_add_item() {

        Inventory i1;
        product_catalog pc;
        char input;
        do
        {
            cout << "\n -------------------------------\n";
            cout << "Enter the product you want to add: ";
            cin >> i1.item;
            //Isb_search("product.bin", i1.item);
            //if (check == true)
            //{
                //cout << "Product found" << endl;
                cout << "Enter the Price of product: ";
                cin >> i1.price;

                ofstream file;

                file.open("Isb_inventory.bin", ios::binary | ios::app);
                if (file.write((char*)&i1, sizeof(i1)))
                {
                    cout << "Successfully Inserted\n" << endl;
                }
                else
                {
                    cout << "Failed" << endl;
                }
                file.close();
            //}
            //else
            //{
             //   cout << "\n* Product not found\n";
           // }
            do
            {
                cout << "Press y to continue / n to exit: ";
                cin >> input;
            } while (input != 'y' && input != 'n');

        } while (input == 'y');


    }
    void Isb_edit_item() {

        char name[25];
        int new_price;
        cout << "Product Name (Update): ";
        cin >> name;
        cout << "Updated Price: ";
        cin >> new_price;
        Isb_update("Isb_inventory.bin", name, new_price);


    }
    void Isb_view_data() {


        ifstream file;
        Inventory i1;
        file.open("Isb_inventory.bin", ios::binary | ios::app);

        while (file.read((char*)&i1, sizeof(i1)))
        {
            cout << "\n-------------------------\n";
            cout << "Product Name  : " << i1.item << endl;
            cout << "Product Price :" << i1.price << endl;


        }

        file.close();
        //add_product();

    }

    void Isb_update(const string filename, string item, int quantity)
    {
        Inventory i3;
        fstream file(file_name.c_str(), ios::in | ios::out | ios::binary);
        while (file.read((char*)&i3, sizeof(i3)))
        {
            if (item == i3.item)
            {
                i3.price = quantity;
                int first_ptr = file.tellg();
                int size = sizeof(i3);
                file.seekp(first_ptr - size, ios::beg);
                file.write((char*)&i3, sizeof(i3));
                file.close();
            }
        }

    }

    void Isb_search(const string filename, string product)
    {
        product_catalog pc;
        fstream file(file_name.c_str(), ios::in | ios::out | ios::binary);
        while (file.read((char*)&pc, sizeof(pc)))
        {
            if (product == pc.prod_name)
            {
                check = true;
                cout << "Yes\n";
                file.close();

            }
            else
            {
                check = false;
            }
        }

    }

    void Isb_delete_item() {
        string product;
        Inventory p;
        cout << "Eneter the product you want to delete: ";
        cin >> product;
        fstream myFile(filename.c_str(), ios::in | ios::out | ios::binary);
        ofstream myFileTemp("Isb_inventory.bin", ios::app | ios::binary);
        while (myFile.read((char*)&p, sizeof(p))) {
            if (p.item != product) {
                myFileTemp.write((char*)&p, sizeof(p));
            }
        }


        myFile.close();
        myFileTemp.close();
        remove(filename.c_str());
        rename("Isb_inventory.bin", filename.c_str());
    }


};
//********************************************************************

// Shopping Class

//*******************************************************************

class Shopping
{
public:
    char item[25];
    int quantity;
    int price;
    int sum ;
    bool check = false;
    char customer_n[25];
    char input;

    void prod_cart() {
        Shopping s1;
        product_catalog i1;
        display_catalog();
        cout << "\n-----------------------------\n";
        cout << "Enter the Customer Name: ";
        cin >> customer_n;
        cout << "[ CART ]" << endl;
        sum = 0;
        int choice;
        do
        {
            cout << "Press 1 if you are from same city\nPress 2 if you are from out of city\nPress: ";
            cin >> choice;
        } while (choice != 1 && choice != 2);


        if (choice == 1)
        {
            cout << "Delivery charges are Rs. 30\n";
            sum = sum + 30;
        }
        else
        {
            cout << "Delivery charges are Rs. 50\n";
            sum = sum + 50;
        }
       
        do
        {
            //price = 0;
            cout << "\n -------------------------------\n";
            cout << "Enter the product you want to add: ";
            cin >> item;
            search("product.bin", item);

            if (check == true)
            {
                int kela;
                //cout << price << endl;
                cout << "Product found" << endl;
                cout << "Enter the Quantity of product: ";
                cin >> quantity;
                kela = price * quantity;
                //cout << kela << endl;
               // cout << s1.price << endl;
                sum = sum + kela;
                //cout << sum << endl;
                ofstream file;

                file.open("cart.bin", ios::binary | ios::app);
                if (file.write((char*)&s1, sizeof(s1)))
                {
                    cout << "Successfully Inserted\n" << endl;
                }
                else
                {
                    cout << "Failed" << endl;
                }
                file.close();
            }
            else
            {
                cout << "\n* Product not found\n";
            }
            do
            {
                cout << "Press y to continue shopping / n to checkout: ";
                cin >> input;
            } while (input != 'y' && input != 'n');

        } while (input == 'y');


        if (choice == 1)
        {
            cout << "Delivery charges are Rs. 30\n";
          
        }
        else
        {
            cout << "Delivery charges are Rs. 50\n";
           
        }
        cout << "-------------------\n";
        cout << "\nBill : " << sum << endl;
        cout << "\n-------------------\n";

        payment();
        
    }

    void display_catalog() {
        ifstream file;
        product_catalog i1;
        file.open("product.bin", ios::binary | ios::app);

        while (file.read((char*)&i1, sizeof(i1)))
        {
            cout << "\n-------------------------\n";
            cout << "Product Name  : " << i1.prod_name << endl;
            cout << "Product Price :" << i1.prod_price << endl;
            cout << "Product Unit  :" << i1.prod_unit << endl;


        }

        file.close();
    }
    void search(const string filename, string product)
    {
        product_catalog pc;
        fstream file(file_name.c_str(), ios::in | ios::out | ios::binary);
        while (file.read((char*)&pc, sizeof(pc)))
        {
            if (product == pc.prod_name)
            {
                check = true;
                //cout << "Yes\n";
                price = pc.prod_price;
               // cout << price;
                file.close();


            }
            else
            {
                check = false;
            }
        }
        
        
    }

    //********************************************************************

// Payment 

//*******************************************************************
    void payment() {
        int choice;
        cout << "Enter the Payment Method\n";
        cout << "\n -----------------------\n";
        cout << "|1. Cash on Delivery     |\n";
        cout << "|2. JazzCash             |\n";
        cout << "|3. Bank Account         |\n";
        cout << "\n -----------------------\n";
        do
        {
            cout << "Press: ";
            cin >> choice;
        } while (choice != 1 && choice != 2 && choice != 3 );

        if (choice == 1)
        {

            cod();
           
        }
        if (choice == 2)
        {
            jazzcash();
        }
        if (choice == 3)
        {
            bank();
        }



    }

    void cod() {
        string cod;
        cout << "\n -----------------------\n";
        cout << "Enter your address\n";
        cin >> cod;
        cout << "Wait for your delivery......" << endl;
        int ch;
        
            do
            {
                cout << "Press 1 to give your Feedback\nPress 2 to Exit \n";
                cin >> ch;
            } while (ch != 1 && ch != 2);
            if (ch == 1)
            {
                feedback();
            }
            else
            {
                system("CLS");
                main();
            }
    }
    void jazzcash() {
        string jazz;
        cout << "\n -----------------------\n";
        cout << "Enter your Jazzcash Account\n";
        cin >> jazz;
        cout << "Wait for your transaction......" << endl;
        cout << "Transaction Successful" << endl;
        cout << "\n -----------------------\n";
        int ch;

        do
        {
            cout << "Press 1 to give your Feedback\nPress 2 to Exit \n";
            cin >> ch;
        } while (ch != 1 && ch != 2);
        if (ch == 1)
        {
            feedback();
        }
        else
        {
            system("CLS");
            main();
        }
    }
    void bank() {
        string bnk;
        cout << "\n -----------------------\n";
        cout << "Enter your Bank Account\n";
        cin >> bnk;
        cout << "Wait for your transaction......" << endl;
        cout << "Transaction Successful" << endl;
        int ch;
        cout << "\n -----------------------\n";
        do
        {
            cout << "Press 1 to give your Feedback\nPress 2 to Exit \n";
            cin >> ch;
        } while (ch != 1 && ch != 2);
        if (ch == 1)
        {
            feedback();

        }
        else
        {
            system("CLS");
            main();
        }
    }
    void feedback() {

        char feedb[100];
        for (int  i = 0; i < 100; i++)
        {
            feedb[i] = '\n';
        }
        cout << "Enter your Feedback: ";
        cin >> feedb;

        ofstream file("feedback.bin", ios::binary | ios::app);

        if (file.write((char*)&feedb, sizeof(feedb)))
        {
            cout << "Successfully Inserted\n" << endl;
        }
        else
        {
            cout << "Failed" << endl;
        }
        file.close();

        cout << "Thank for your feedback." << endl;
        system("CLS");
        main();
    }

}; 





//********************************************************************

// Manager Class

//*******************************************************************

class manager : public User
{
    char user_name[100];
public:
    manager() {
        for (int i = 0; i < 100; i++)
        {
            user_name[i] = '\0';
        }
    }
    manager(string user_n, string n,
        string pass, string cnic,
        string ph, string adress)
        : User(n, pass, cnic, ph, adress)
    {
        strcpy_s(this->user_name, user_n.c_str());
        strcpy_s(this->name, n.c_str());
        strcpy_s(this->password, pass.c_str());
        strcpy_s(this->CNIC, cnic.c_str());
        strcpy_s(this->phone, ph.c_str());
        strcpy_s(this->adress, adress.c_str());
    }
    void setUserName(string user_n) {
        strcpy_s(this->user_name, user_n.c_str());
    }
    string getUserName() {
        return user_name;
    }
    void setName(string n1) {
        strcpy_s(this->name, n1.c_str());
    }
    string getName() {
        return name;
    }
    void setpass(string p1) {
        strcpy_s(this->password, p1.c_str());
    }
    string getpass() {
        return password;
    }
    void setCNIC(string cnic1) {
        strcpy_s(this->CNIC, cnic1.c_str());
    }
    string getCNIC() {
        return CNIC;
    }
    void setPhone(string p1) {
        strcpy_s(this->phone, p1.c_str());
    }
    string getPhone() {
        return phone;
    }
    void setAddress(string A1) {
        strcpy_s(this->adress, A1.c_str());
    }
    string getAddress() {
        return adress;
    }

    void login() {
        string user_N1, pw1;
        manager m2;
        Inventory i;
        bool pass_check = true, user_check = true;

        //file.open("customer.bin", ios::binary);//opening binary file
        //if (!file)
        //{
        //    cout << "Error in opening file" << endl;
        //}
        //file.write((char*)&c2, sizeof(c2));//writing in binary file
        //file.close();
        cout << "\n\t   (WELCOME,MANAGER)\n";
        cout << "\n\t=================\n";
        cout << "\t||  LOGIN MENU   ||\n";
        cout << "\t=================\n";

        ifstream file;
        do
        {
            user_check = true;
            file.open("manager.bin", ios::in | ios::binary);//opening admin file again for check
            if (!file)
            {
                cout << "Error in opening\n";
            }
            cout << "\n__________________________\n";
            cout << "Enter Username: ";
            cin >> user_N1;
            //reading binary file
            if (file.read((char*)&m2, sizeof(m2)))
            {
                if (user_N1 != m2.user_name)
                {
                    cout << "\n__________________________\n";
                    cout << "\tIncorrect Username ";
                    cout << "\n__________________________\n";
                    user_check = false;
                }
                else
                {
                    cout << "\n__________________________\n";
                    cout << "\tCorrect Username ";
                    cout << "\n__________________________\n";
                }
            }

            file.close();
        } while (user_check == false);

        do
        {
            pass_check = true;
            file.open("manager.bin", ios::in | ios::binary);//opening admin file again for check
            if (!file)
            {
                cout << "Error in opening\n";
            }
            cout << "\n__________________________\n";
            cout << "Enter Password: ";
            cin >> pw1;
            if (file.read((char*)&m2, sizeof(m2)))
            {

                if (pw1 != m2.password)
                {
                    cout << "\n__________________________\n";
                    cout << "\tIncorrect Password ";
                    cout << "\n__________________________\n";
                    pass_check = false;
                }
                else
                {
                    cout << "\n__________________________\n";
                    cout << "\tCorrect Password ";
                    cout << "\n__________________________\n";
                    pass_check = true;
                    break;
                }
            }
            file.close();
        } while (pass_check == false);

        cout << "\n_________________________________\n";
        cout << "|You have Loggined Successfully  |" << endl;
        cout << "|__________________________________|\n";

        //main();
        int choice1,choice2;
       
        cout << "\n\t( MANAGER MENU )\n";
        cout << "\n ____________________\n";
        cout << "|1. Inventory          |\n";
        cout << "|2. Logout             |\n";
        cout << "|______________________|\n";
        do
        {
            cout << "Press: ";
            cin >> choice1;
        } while (choice1 != 1 && choice1 != 2 );

        if (choice1 == 1)
        {
            cout << "\n\t( INVENTORY MENU )\n";
            cout << "\n ____________________\n";
            cout << "|1. Multan Store       |\n";
            cout << "|2. Islamabad Store    |\n";
            cout << "|2. Main Menu          |\n";
            cout << "|______________________|\n";
            do
            {
                cout << "Press: ";
                cin >> choice1;
            } while (choice1 != 1 && choice1 != 2);

            if (choice1 == 1) {
                i.multan_store();
            }
            if (choice1 == 2)
            {
                i.isb_store();
            }
            if (choice1 == 3)
            {
                main();
            }
        }
        if (choice1 == 2)
        {
            main();
        }
        

    }


};


//********************************************************************

// ADMIN CLASS

//*******************************************************************


class admin : public User
{
    char username[100];
public:
    //Parameterlized constructor to give admin its information
    admin(string u_name = "raza123", string n = "M.Raza",
        string pass = "Raza@123", string cnic = "3610381587375",
        string ph = "03041506231", string adress = "F-11")
        : User(n, pass, cnic, ph, adress)
    {
        strcpy_s(this->username, u_name.c_str());
        strcpy_s(this->name, n.c_str());
        strcpy_s(this->password, pass.c_str());
        strcpy_s(this->CNIC, cnic.c_str());
        strcpy_s(this->phone, ph.c_str());
        strcpy_s(this->adress, adress.c_str());
    }


    string getU_name() {
        return username;
    }
    string getName() {
        return name;
    }
    string getPass() {
        return password;
    }
    string getCnic() {
        return CNIC;
    }

    string getPhone() {
        return phone;
    }
    string getAddress() {
        return adress;
    }

    void login() {
        string user_N1, pw1;
        admin a1;
        int choice1;
        bool pass_check = true, user_check = true;


        fstream file;
        file.open("admin.bin", ios::out | ios::binary);//opening binary file
        if (!file)
        {
            cout << "Error in opening file" << endl;
        }
        file.write((char*)&a1, sizeof(a1));//writing in binary file
        file.close();

        cout << "\n\t   ( WELCOME,ADMIN )\n";
        cout << "\n\t=================\n";
        cout << "\t||  LOGIN MENU   ||\n";
        cout << "\t=================\n";

        do
        {
            user_check = true;
            file.open("admin.bin", ios::in | ios::binary);//opening admin file again for check
            if (!file)
            {
                cout << "Error in opening\n";
            }
            cout << "\n__________________________\n";
            cout << "Enter Username: ";
            cin >> user_N1;
            //reading binary file
            if (file.read((char*)&a1, sizeof(a1)))
            {
                if (user_N1 != a1.getU_name())
                {
                    cout << "\nIncorrect username \n";
                    user_check = false;
                }
                else
                {
                    cout << "Correct Username \n";
                    user_check = true;
                }
            }

            file.close();
        } while (user_check == false);

        do
        {
            pass_check == true;
            file.open("admin.bin", ios::in | ios::binary);//opening admin file again for check
            if (!file)
            {
                cout << "Error in opening\n";
            }
            cout << "\n__________________________\n";
            cout << "Enter Password: ";
            cin >> pw1;
            if (file.read((char*)&a1, sizeof(a1)))
            {
                if (pw1 != a1.getPass())
                {
                    cout << "\nIncorrect Password \n";
                    pass_check = false;
                }
                else if (pw1 == a1.getPass())
                {
                    cout << "Correct Password \n";
                    pass_check == true;
                    break;
                }
            }
            file.close();
        } while (pass_check == false);

        display_admin();

    }

    void display_admin() {
        int choice1;
        product_catalog p;
        cout << "\n\t( ADMIN MENU )\n";
        cout << "\n _________________________________\n";
        cout << "|1. Manager Registration          |\n";
        cout << "|2. Manage Product Catalog        |\n";
        cout << "|3. Main Menu                     |\n";
        cout << "|_________________________________|\n";
        do
        {
            cout << "Press: ";
            cin >> choice1;
        } while (choice1 != 1 && choice1 != 2 && choice1 != 3 && choice1!=4);
        if (choice1 == 1)
        {
            manager_reg();
        }
        if (choice1==2)
        {
            //p.catalog_display();
            manage_catalog();
        }
        if (choice1 == 3)
        {
            main();
        }
    }

    void manage_catalog() {
        int choice1;
        product_catalog p;
        cout << "\n _______________________________\n";
        cout << "|1. Add Products                  |\n";
        cout << "|2. View Products                 |\n";
        cout << "|3. Edit/Update Products          |\n";
        cout << "|4. Delete Products               |\n";
        cout << "|5. Main Menu                     |\n";
        cout << "|_________________________________|\n";
        do
        {
            cout << "Press: ";
            cin >> choice1;
        } while (choice1 != 1 && choice1 != 2 && choice1 != 3 && choice1 != 4 && choice1 != 5);
        if (choice1 == 1) {
            p.add_product();
        }
        else if (choice1==2)
        {
            p.catalog_display();
        }
        else if (choice1 == 3)
        {
            p.edit_product();
        }
        else if (choice1 == 4)
        {
            p.remove_product();
        }
        else if (choice1==5)
        {
            display_admin();
        }
    }

    void manager_reg() {
        string user, name, pass, re_pass, cnic, phone, adress;
        bool pass_check = true, cnic_check = true, recheck = true, phone_check = true;
        int Special_count = 0, Upper_count = 0, Lower_count = 0, Numeric_count = 0;
        manager temp, c1;

        cout << "\n======================\n";
        cout << "\n||  MANAGER REGISTRATION  ||\n\n";
        cout << "Enter Name: ";
        cin >> name;
        cout << "\n======================\n";
        cout << "\nEnter Username: ";
        cin >> user;



        do
        {
            cnic_check = true;
            cout << "\n======================\n";
            cout << "\nEnter the CNIC (13 Digits only):";
            cin >> cnic;
            if (cnic.length() != 13)
            {
                cnic_check = false;
                cout << "***************************************" << endl;
                cout << "Invalid CNIC. It must contain 13 digits" << endl;
                cout << "***************************************" << endl;
            }
            else
            {
                cnic_check = true;
            }
            for (int i = 0; cnic[i] != '\0'; i++)
            {
                if (cnic[i] < 48 || cnic[i] > 57)
                {
                    cout << "***************************************" << endl;
                    cout << "Your CNIC is invalid. CNIC must be numbers only" << endl;
                    cout << "***************************************" << endl;
                    cnic_check = false;
                    break;
                }
            }
        } while (cnic_check == false);


        int check1;
        fstream file1;
        file1.open("manager.bin", ios::out | ios::binary);//opening binary file
        if (!file1)
        {
            cout << "Error in opening file" << endl;
        }

        do {
            check1 = 0;
            while (file1.read((char*)&temp, sizeof(temp)))
            {
                if (cnic == c1.getCNIC())
                {
                    cout << "***************************************" << endl;
                    cout << "This CNIC has been registered previously" << endl;
                    cout << "***************************************" << endl;
                    cout << "Enter the CNIC again : ";
                    cin >> cnic;
                    check1 == 1;
                }
            }
            file1.close();

        } while (check1 == 1);



        do
        {
            pass_check = true;
            cout << "\n======================\n";
            cout << "\nEnter Password: ";
            cin >> pass;
            if (pass.length() < 8)
            {
                pass_check = false;
                cout << "***************************************" << endl;
                cout << "Invalid password. It must contain 8 digits" << endl;
                cout << "***************************************" << endl;
            }
            for (int i = 0; pass[i] != '\0'; i++)
            {
                if ((pass[i] >= 32 && pass[i] <= 47) || (pass[i] >= 58 && pass[i] <= 64) ||
                    (pass[i] >= 91 && pass[i] <= 96) || (pass[i] >= 123 && pass[i] <= 126))
                {
                    ++Special_count;
                }
                if (pass[i] >= 65 && pass[i] <= 90)
                {
                    ++Upper_count;
                }
                if (pass[i] >= 97 && pass[i] <= 122)
                {
                    ++Lower_count;
                }
                if (pass[i] >= 48 && pass[i] <= 57)
                {
                    ++Numeric_count;
                }
            }

            if (Special_count == 0 || Upper_count == 0 || Lower_count == 0 || Numeric_count == 0) {
                pass_check = false;
                cout << "***************************************" << endl;
                cout << "Password must include atleast one special character, uppercase, lowercase, and number" << endl;
                cout << "***************************************" << endl;
            }


        } while (pass_check == false);

        do
        {
            recheck = true;
            cout << "\n======================\n";
            cout << "\nReEnter password for verfication: ";
            cin >> re_pass;
            if (pass == re_pass)
            {
                strcpy_s(password, pass.c_str());
            }
            else
            {
                recheck = false;
                cout << "Passwords do not match" << endl;
            }

        } while (recheck == false);

        do
        {
            cout << "\n======================\n";
            phone_check = true;
            cout << "\nEnter Phone Number: ";
            cin >> phone;
            for (int i = 0; phone[i] != '\0'; i++)
            {
                if (phone[i] < 48 || phone[i] > 57)
                {
                    cout << "It must be numbers only" << endl;
                    phone_check = false;
                }
            }
            if (phone.length() != 11)
            {
                phone_check = false;
                cout << "***************************************" << endl;
                cout << "Invalid number. It must contain 11 digits" << endl;
                cout << "***************************************" << endl;
            }


        } while (phone_check == false);

        cout << "\n======================\n";
        cout << "\nEnter Address: ";
        cin >> adress;

        c1.setUserName(user);
        c1.setName(name);
        c1.setCNIC(cnic);
        c1.setpass(pass);
        c1.setPhone(phone);
        c1.setAddress(adress);

        fstream fil;
        fil.open("manager.bin", ios::binary | ios::app);//opening binary file
        if (!fil)
        {
            cout << "Error in opening file" << endl;
        }
        fil.write((char*)&c1, sizeof(c1));//writing in binary file
        fil.close();

        cout << "\n_________________________________\n";
        cout << "|You have Registered Successfully  |" << endl;
        cout << "|__________________________________|\n";

        display_admin();
    }

};



//********************************************************************

// CUSTOMER CLASS

//*******************************************************************



class customer : public User
{
    char user_name[100];
public:
    customer() {
        for (int i = 0; i < 100; i++)
        {
            user_name[i] = '\0';
        }
    }
    customer(string user_n, string n,
        string pass, string cnic,
        string ph, string adress)
        : User(n, pass, cnic, ph, adress)
    {
        strcpy_s(this->user_name, user_n.c_str());
        strcpy_s(this->name, n.c_str());
        strcpy_s(this->password, pass.c_str());
        strcpy_s(this->CNIC, cnic.c_str());
        strcpy_s(this->phone, ph.c_str());
        strcpy_s(this->adress, adress.c_str());
    }
    void setUserName(string user_n) {
        strcpy_s(this->user_name, user_n.c_str());
    }
    string getUserName() {
        return user_name;
    }
    void setName(string n1) {
        strcpy_s(this->name, n1.c_str());
    }
    string getName() {
        return name;
    }
    void setpass(string p1) {
        strcpy_s(this->password, p1.c_str());
    }
    string getpass() {
        return password;
    }
    void setCNIC(string cnic1) {
        strcpy_s(this->CNIC, cnic1.c_str());
    }
    string getCNIC() {
        return CNIC;
    }
    void setPhone(string p1) {
        strcpy_s(this->phone, p1.c_str());
    }
    string getPhone() {
        return phone;
    }
    void setAddress(string A1) {
        strcpy_s(this->adress, A1.c_str());
    }
    string getAddress() {
        return adress;
    }
    void registeration() {
        string user, name, pass, re_pass, cnic, phone, adress;
        bool pass_check = true, cnic_check = true, recheck = true, phone_check = true;
        int Special_count = 0, Upper_count = 0, Lower_count = 0, Numeric_count = 0;
        customer temp, c1;

        cout << "\n======================\n";
        cout << "\n||  CUSTOMER REGISTRATION  ||\n\n";

        cout << "\n======================\n";
        cout << "Enter Name: ";
        cin >> c1.name;
        cout << "\n======================\n";
        cout << "\nEnter Username: ";
        cin >> c1.user_name;



        do
        {
            cnic_check = true;
            cout << "\n======================\n";
            cout << "\nEnter the CNIC (13 Digits only):";
            cin >> c1.CNIC;
            if (c1.getCNIC().length() != 13)
            {
                cnic_check = false;
                cout << "***************************************" << endl;
                cout << "Invalid CNIC. It must contain 13 digits" << endl;
                cout << "***************************************" << endl;
            }
            for (int i = 0; c1.CNIC[i] != '\0'; i++)
            {
                if (c1.CNIC[i] < 48 || c1.CNIC[i] > 57)
                {
                    cout << "***************************************" << endl;
                    cout << "Your CNIC is invalid. CNIC must be numbers only" << endl;
                    cout << "***************************************" << endl;
                    cnic_check = false;
                    break;
                }
            }
        } while (cnic_check == false);


        int check1;
        fstream file1;
        file1.open("customer.bin", ios::out | ios::binary);//opening binary file
        if (!file1)
        {
            cout << "Error in opening file" << endl;
        }

        do {
            check1 = 0;
            while (file1.read((char*)&temp, sizeof(temp)))
            {
                if (temp.CNIC == c1.CNIC)
                {
                    cout << "***************************************" << endl;
                    cout << "This CNIC has been registered previously" << endl;
                    cout << "***************************************" << endl;
                    cout << "Enter the CNIC again : ";
                    cin >> c1.CNIC;
                    check1 == 1;
                }
            }
            file1.close();

        } while (check1 == 1);



        do
        {
            pass_check = true;
            cout << "\n======================\n";
            cout << "\nEnter Password: ";
            cin >> c1.password;
            if (c1.getpass().length() < 8)
            {
                pass_check = false;
                cout << "***************************************" << endl;
                cout << "Invalid password. It must contain 8 digits" << endl;
                cout << "***************************************" << endl;
            }

            //Checks for the conditions of password

            for (int i = 0; c1.password[i] != '\0'; i++)
            {
                if ((c1.password[i] >= 32 && c1.password[i] <= 47) || (c1.password[i] >= 58 && c1.password[i] <= 64) ||
                    (c1.password[i] >= 91 && c1.password[i] <= 96) || (c1.password[i] >= 123 && c1.password[i] <= 126))
                {
                    ++Special_count;
                }
                if (c1.password[i] >= 65 && c1.password[i] <= 90)
                {
                    ++Upper_count;
                }
                if (c1.password[i] >= 97 && c1.password[i] <= 122)
                {
                    ++Lower_count;
                }
                if (c1.password[i] >= 48 && c1.password[i] <= 57)
                {
                    ++Numeric_count;
                }
            }

            if (Special_count == 0 || Upper_count == 0 || Lower_count == 0 || Numeric_count == 0) {
                pass_check = false;
                cout << "***************************************" << endl;
                cout << "Password must include atleast one special character, uppercase, lowercase, and number" << endl;
                cout << "***************************************" << endl;
            }


        } while (pass_check == false);

        //Rechecking the password

        do
        {
            recheck = true;
            cout << "\n======================\n";
            cout << "\nReEnter password for verfication: ";
            cin >> re_pass;
            if (c1.password == re_pass)
            {
                strcpy_s(password, pass.c_str());
            }
            else
            {
                recheck = false;
                cout << "Passwords do not match" << endl;
            }

        } while (recheck == false);

        do
        {
            cout << "\n======================\n";
            phone_check = true;
            cout << "\nEnter Phone Number: ";
            cin >> c1.phone;
            for (int i = 0; c1.phone[i] != '\0'; i++)
            {
                if (c1.phone[i] < 48 || c1.phone[i] > 57)
                {
                    cout << "It must be numbers only" << endl;
                    phone_check = false;
                }
            }
            if (c1.getPhone().length() != 11)
            {
                phone_check = false;
                cout << "***************************************" << endl;
                cout << "Invalid number. It must contain 11 digits" << endl;
                cout << "***************************************" << endl;
            }


        } while (phone_check == false);

        cout << "\n======================\n";
        cout << "\nEnter Address: ";
        cin >> c1.adress;

        //writing data in the file

        ofstream file("customer.bin", ios::binary | ios::app);

        if (file.write((char*)&c1, sizeof(c1)))
        {
            cout << "Successfully Inserted\n" << endl;
        }
        else
        {
            cout << "Failed" << endl;
        }
        file.close();

        cout << "\n_________________________________\n";
        cout << "|You have Registered Successfully  |" << endl;
        cout << "|__________________________________|\n";

        login();

    }



                                                                                                                       
    void login() {
        string user_N1, pw1;
        customer c2;
        bool pass_check = true, user_check = true;
        ifstream file;
        //file.open("customer.bin", ios::binary);//opening binary file
        //if (!file)
        //{
        //    cout << "Error in opening file" << endl;
        //}
        //file.write((char*)&c2, sizeof(c2));//writing in binary file
        //file.close();
        cout << "\n\t   ( WELCOME,CUSTOMER )\n";
        cout << "\n\t=================\n";
        cout << "\t||  LOGIN MENU   ||\n";
        cout << "\t=================\n";

        do
        {
            user_check = true;
            file.open("customer.bin", ios::in | ios::binary);//opening admin file again for check
            if (!file)
            {
                cout << "Error in opening\n";
            }
            cout << "\n__________________________\n";
            cout << "Enter Username: ";
            cin >> user_N1;
            //reading binary file
            if (file.read((char*)&c2, sizeof(c2)))
            {
                if (user_N1 != c2.user_name)
                {
                    cout << "\n__________________________\n";
                    cout << "\tIncorrect Username ";
                    cout << "\n__________________________\n";
                    user_check = false;
                }
                else
                {
                    cout << "\n__________________________\n";
                    cout << "\tCorrect Username ";
                    cout << "\n__________________________\n";
                }
            }

            file.close();
        } while (user_check == false);

        do
        {
            pass_check = true;
            file.open("customer.bin", ios::in | ios::binary);//opening admin file again for check
            if (!file)
            {
                cout << "Error in opening\n";
            }
            cout << "\n__________________________\n";
            cout << "Enter Password: ";
            cin >> pw1;
            if (file.read((char*)&c2, sizeof(c2)))
            {

                if (pw1 != c2.password)
                {
                    cout << "\n__________________________\n";
                    cout << "\tIncorrect Password ";
                    cout << "\n__________________________\n";
                    pass_check = false;
                }
                else
                {
                    cout << "\n__________________________\n";
                    cout << "\tCorrect Username ";
                    cout << "\n__________________________\n";
                }
            }
            file.close();
        } while (pass_check == false);

        cout << "\n_________________________________\n";
        cout << "|You have Loggined Successfully  |" << endl;
        cout << "|__________________________________|\n";

        customer_menu();
    }

    void customer_menu() {
        int choice1;
        product_catalog p;
        Shopping s1;
        cout << "\n\t( Welcome, Customer )\n";
        cout << "\n __________________________\n";
        cout << "|1. Online Shopping          |\n";
        cout << "|2. Logout                   |\n";
        cout << "|____________________________|\n";
        do
        {
            cout << "Press: ";
            cin >> choice1;
        } while (choice1 != 1 && choice1 != 2 && choice1 != 3 && choice1 != 4);
        if (choice1 == 1)
        {
            s1.prod_cart();
        }
        
        if (choice1 == 2)
        {
            main();
        }
    }


};
