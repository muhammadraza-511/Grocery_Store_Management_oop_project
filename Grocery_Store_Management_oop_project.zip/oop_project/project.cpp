#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>
#include"customer.h"
using namespace std;

// Class for user
int main();


//********************************************************************

// Product Catalog

//*******************************************************************





int main() {

    int choice1,choice2;
    admin a1;
    customer c1;
    manager m1;
    cout << "\t\t****************************\n";
    cout << "\t\t* WELCOME TO GROCERY STORE *\n";
    cout << "\t\t****************************\n\n";
    cout << "\t\t\t ==========\n";
    cout << "\t\t\t||  MENU  ||\n";
    cout << "\t\t\t ==========\n\n";
    cout << " ==========================\n";
    cout << "|| 1. Admin               ||\n";
    cout << "|| 2. Manager             ||\n";
    cout << "|| 3. Customer            ||\n";
    cout << "|| 4. Exit                ||\n";
    cout << "||========================||\n";
    do
    {
        cout << "Press: ";
        cin >> choice1;
    } while (choice1!=1 && choice1 != 2 && choice1 != 3 && choice1!=4);
    
    if (choice1 == 1)
    {
        a1.login();
    }
    else if (choice1==3)
    {
        cout << "\n\t   ( WELCOME,CUSTOMER )\n";
        int choice2;
        cout << " ___________________\n";
        cout << "|Press 1 to Register|\n";
        cout << "|Press 2 to Login   |\n";
        cout << "|___________________|\n";
        do
        {
            cout << "Press: ";
            cin >> choice2;
        } while (choice2 != 1 && choice2 != 2);
        if (choice2==1)
        {
            c1.registeration();
        }
        if (choice2 == 2)
        {
            c1.login();
        }
    }
    else if (choice1==2)
    {
        m1.login();
    }
    else if (choice1==4)
    {
        cout << "(THANKS, GOOD BYE)" << endl;
        return 0;
    }
}